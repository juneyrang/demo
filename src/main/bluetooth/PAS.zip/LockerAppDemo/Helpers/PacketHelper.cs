﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LockerAppDemo.Helpers
{
    public class PacketHelper
    {
        #region Locker Key
        public static readonly int[] KEY_LOCKER_OKGSS101_1 = new int[] { 58, 96, 67, 42, 92, 01, 33, 31, 41, 30, 15, 78, 12, 19, 40, 37 };

        public static readonly byte[] key = { 58, 96, 67, 42, 92, 01, 33, 31, 41, 30, 15, 78, 12, 19, 40, 37 };
        #endregion

        #region Locker Packet
        public static readonly byte[] PACKET_LOCKER_OPEN = new byte[] { 0x05, 0x01, 0x06 };
        public static readonly byte[] PACKET_LOCKER_PASSWORD = new byte[] { 0x30, 0x30, 0x30, 0x30, 0x30, 0x30 };
        #endregion

        private static byte[] token = new byte[4];

        public static void SetToken()
        {

        }

        public static byte[] GetTokenPacket(String deviceKey)
        {
            byte[] byteToken = { 0x06, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
            //byte[] encryptStringToBytes = Encrypt(byteToken, key);
            byte[] encryptStringToBytes = Encrypt(byteToken, intToByte(PacketHelper.KEY_LOCKER_OKGSS101_1));

            Debug.WriteLine($"deviceKey String : {deviceKey}");
            Debug.WriteLine($"KEY_LOCKER_OKGSS101 String : {ByteToHex(intToByte(PacketHelper.KEY_LOCKER_OKGSS101_1))}");
            return encryptStringToBytes;
        }

        public static byte[] LockOpenPacket(byte[] token)
        {
            byte[] byteOpenLock = new byte[PACKET_LOCKER_OPEN.Length + PACKET_LOCKER_PASSWORD.Length + token.Length];
            int index = 0;
            Array.Copy(PACKET_LOCKER_OPEN, 0, byteOpenLock, index, PACKET_LOCKER_OPEN.Length);
            index += PACKET_LOCKER_OPEN.Length;
            Array.Copy(PACKET_LOCKER_PASSWORD, 0, byteOpenLock, index, PACKET_LOCKER_PASSWORD.Length);
            index += PACKET_LOCKER_PASSWORD.Length;
            Array.Copy(token, 0, byteOpenLock, index, token.Length);

            byte[] encryptStringToBytes = Encrypt(byteOpenLock, intToByte(PacketHelper.KEY_LOCKER_OKGSS101_1));

            return encryptStringToBytes;
        }

        private static byte[] Encrypt(byte[] EncryptArray, byte[] KeyArray)
        {
            RijndaelManaged Rdel = new RijndaelManaged();
            Rdel.Mode = CipherMode.ECB;
            Rdel.Padding = PaddingMode.Zeros;
            //Rdel.KeySize = 128;
            Rdel.Key = KeyArray;

            ICryptoTransform CtransForm = Rdel.CreateEncryptor();
            byte[] ResultArray = CtransForm.TransformFinalBlock(EncryptArray, 0, EncryptArray.Length);

            string hexString = ByteToHex(ResultArray);
            Debug.WriteLine($"Encrypt String : {hexString}");

            return HexToByte(hexString);
        }

        public static byte[] Decrypt(byte[] DecryptArray, byte[] KeyArray)
        {
            RijndaelManaged Rdel = new RijndaelManaged();
            Rdel.Mode = CipherMode.ECB;
            Rdel.Padding = PaddingMode.Zeros;
            //Rdel.KeySize = 128;
            Rdel.Key = KeyArray;

            ICryptoTransform CtransForm = Rdel.CreateDecryptor();
            byte[] ResultArray = CtransForm.TransformFinalBlock(DecryptArray, 0, DecryptArray.Length);

            return ResultArray;
        }

        private static byte[] intToByte(int[] intArray)
        {
            byte[] hexByteArray = new byte[intArray.Length];
            for (int i = 0; i < intArray.Length; i++)
            {
                hexByteArray[i] = (byte)intArray[i]; // 각 요소를 16진수 byte로 변환하여 저장합니다.
            }
            return hexByteArray;
        }

        public static byte[] IntToByteArray(int[] intArray)
        {
            byte[] hexByteArray = new byte[intArray.Length]; // 16진수로 변환한 바이트 배열을 저장할 배열

            for (int i = 0; i < intArray.Length; i++)
            {
                string hex = intArray[i].ToString("x");
                if (hex.Length % 2 != 0)
                {
                    hex = "0" + hex;
                }

                hexByteArray[i] = Convert.ToByte(hex, 16);
                //hexByteArray[i] = (byte)intArray[i]; // 10진수 값을 바로 16진수 바이트로 변환
            }

            Debug.WriteLine($"ConvertIntArrayToHexByteArray : {ByteToHex(hexByteArray)}");
            return hexByteArray;
        }

        private static byte[] HexToByte(string hex)
        {
            hex = hex.Replace(" ", "");
            byte[] bytes = new byte[hex.Length / 2];
            for (int i = 0; i < hex.Length; i += 2)
            {
                bytes[i / 2] = (byte)Convert.ToByte(hex.Substring(i, 2), 16);
            }
            return bytes;
        }

        private static String ByteToHex(byte[] ResultArray)
        {
            StringBuilder sbResult = new StringBuilder();
            foreach (byte b in ResultArray)
            {
                sbResult.AppendFormat("{0:x2}", b);
            }

            return sbResult.ToString();
        }

    }
}
