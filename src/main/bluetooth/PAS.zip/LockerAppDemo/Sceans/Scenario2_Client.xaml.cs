﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Devices.Bluetooth;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Threading.Tasks;
using Windows.UI.Core;
using Microsoft.VisualBasic;
using System.Text;
using Windows.Security.Cryptography;
using Windows.Storage.Streams;
using LockerAppDemo.Helpers;
using System.Diagnostics;
using Windows.Devices.Enumeration;
using System.Reflection.PortableExecutable;

// 빈 페이지 항목 템플릿에 대한 설명은 https://go.microsoft.com/fwlink/?LinkId=234238에 나와 있습니다.

namespace LockerAppDemo.Sceans
{
    /// <summary>
    /// 자체적으로 사용하거나 프레임 내에서 탐색할 수 있는 빈 페이지입니다.
    /// </summary>
    public sealed partial class Scenario2_Client : Page
    {
        private MainPage rootPage = MainPage.Current;

        private BluetoothLEDevice bluetoothLeDevice = null;
        private GattCharacteristic selectedCharacteristic;
        private GattCharacteristic readCharacteristic;

        // Only one registered characteristic at a time.
        private GattCharacteristic registeredCharacteristic;
        private GattPresentationFormat presentationFormat;

        private bool subscribedForNotifications = false;

        #region Error Codes
        readonly int E_BLUETOOTH_ATT_WRITE_NOT_PERMITTED = unchecked((int)0x80650003);
        readonly int E_BLUETOOTH_ATT_INVALID_PDU = unchecked((int)0x80650004);
        readonly int E_ACCESSDENIED = unchecked((int)0x80070005);
        readonly int E_DEVICE_NOT_AVAILABLE = unchecked((int)0x800710df); // HRESULT_FROM_WIN32(ERROR_DEVICE_NOT_AVAILABLE)
        #endregion

        #region UI Code
        public Scenario2_Client()
        {
            this.InitializeComponent();
            init();
        }

        private async void init()
        {
            if (rootPage.SelectedBleDeviceId != null)
            {
                await Connect();
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            SelectedDeviceRun.Text = rootPage.SelectedBleDeviceName;
            if (string.IsNullOrEmpty(rootPage.SelectedBleDeviceId))
            {
                ConnectButton.IsEnabled = false;
            }
        }

        protected override async void OnNavigatedFrom(NavigationEventArgs e)
        {
            var success = await ClearBluetoothLEDeviceAsync();
            if (!success)
            {
                rootPage.NotifyUser("Error: Unable to reset app state", NotifyType.ErrorMessage);
            }
        }
        #endregion

        #region Communication
        private async void OpenLockButton_Click()
        {
            //await Connect();
            if (selectedCharacteristic != null)
            {
                await GetToken();
            }
        }

        private async Task Connect()
        {
            if (!await ClearBluetoothLEDeviceAsync())
            {
                rootPage.NotifyUser("Error: Unable to reset state, try again.", NotifyType.ErrorMessage);
                ConnectButton.IsEnabled = false;
                return;
            }

            try
            {
                // BT_Code: BluetoothLEDevice.FromIdAsync must be called from a UI thread because it may prompt for consent.
                bluetoothLeDevice = await BluetoothLEDevice.FromIdAsync(rootPage.SelectedBleDeviceId);

                if (bluetoothLeDevice == null)
                {
                    rootPage.NotifyUser("Failed to connect to device.", NotifyType.ErrorMessage);
                }
                else
                {
                    /*
                    var service = await GetGattDeviceService();
                    if(service != null)
                    {
                        await SetGattCharacteristic(service);
                    }
                    */
                    await AccessDeviceInformationAsync();
                }
            }
            catch (Exception ex) when (ex.HResult == E_DEVICE_NOT_AVAILABLE)
            {
                rootPage.NotifyUser("Bluetooth radio is not on.", NotifyType.ErrorMessage);
            }

        }

        [Obsolete]
        private async Task AccessDeviceInformationAsync()
        {
            if (!String.IsNullOrEmpty(ServiceUUIDValue.Text) && !String.IsNullOrEmpty(CharacteristicUUIDValue.Text))
            {
                GattDeviceServicesResult result = await bluetoothLeDevice.GetGattServicesAsync();
                if (result.Status == GattCommunicationStatus.Success)
                {
                    foreach (var service in result.Services)
                    {
                        if (service.Uuid.Equals(new Guid(ServiceUUIDValue.Text)))
                        {
                            readCharacteristic = service.GetCharacteristics(new Guid(DisplayHelper.readDataUUID))[0];
                            readCharacteristic.ValueChanged += incomingData_ValueChanged;
                            await readCharacteristic.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);

                            GattCharacteristicsResult characteristicsResult = await service.GetCharacteristicsAsync();
                            if (characteristicsResult.Status == GattCommunicationStatus.Success)
                            {
                                foreach (var characteristic in characteristicsResult.Characteristics)
                                {
                                    Console.WriteLine($"Characteristic UUID: {characteristic.Uuid}");
                                    if (characteristic.Uuid.Equals(new Guid(CharacteristicUUIDValue.Text)))
                                    {
                                        selectedCharacteristic = characteristic;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Read data change handler
        async void incomingData_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs eventArgs)
        {
            byte[] readBytes = new byte[eventArgs.CharacteristicValue.Length];
            DataReader.FromBuffer(eventArgs.CharacteristicValue).ReadBytes(readBytes);


            Debug.WriteLine("incomingData_ValueChanged 수신된 dataBytes: " + BitConverter.ToString(readBytes));

            byte[] resultBytes = PacketHelper.Decrypt(readBytes, PacketHelper.key);
            rootPage.NotifyUser($"Read result: {BitConverter.ToString(resultBytes)}", NotifyType.StatusMessage);

            string message = System.Text.Encoding.UTF8.GetString(readBytes);
            Debug.WriteLine($"readData : {message}");

            byte[] resultToken = new byte[4];
            Array.Copy(resultBytes, 3, resultToken, 0, resultToken.Length);
            Debug.WriteLine("resultToken: " + BitConverter.ToString(resultToken));
            Array.Copy(resultBytes, 3, resultToken, 0, resultToken.Length);
            bool value = await OpenLock(PacketHelper.LockOpenPacket(resultToken));
        }


        private async Task<bool> OpenLock(byte[] data)
        {
            var writer = new DataWriter();
            writer.WriteBytes(data);
            var result = await selectedCharacteristic.WriteValueAsync(writer.DetachBuffer());
            if (result == GattCommunicationStatus.Success)
            {
                Debug.WriteLine("OpenLock Data sent successfully");
                return true;
            }
            return false;
        }

        private async Task<GattDeviceService> GetGattDeviceService()
        {
            GattDeviceService s = null;
            GattDeviceServicesResult result = await bluetoothLeDevice.GetGattServicesAsync(BluetoothCacheMode.Uncached);
            if (result.Status == GattCommunicationStatus.Success)
            {
                var services = result.Services;
                rootPage.NotifyUser(String.Format("Found {0} services", services.Count), NotifyType.StatusMessage);
                foreach (var service in services)
                {
                    Debug.WriteLine($"Service Name ===> {DisplayHelper.GetServiceName(service)}, {service.Uuid}, {service.DeviceId}");
                    if (DisplayHelper.GetServiceName(service) == "65255")
                    {
                        s = service;
                        break;
                    }
                }
            }
            return s;
        }

        private async Task SetGattCharacteristic(GattDeviceService service)
        {
            IReadOnlyList<GattCharacteristic> characteristics = null;

            try
            {
                var accessStatus = await service.RequestAccessAsync();
                if (accessStatus == DeviceAccessStatus.Allowed)
                {
                    // BT_Code: Get all the child characteristics of a service. Use the cache mode to specify uncached characterstics only 
                    // and the new Async functions to get the characteristics of unpaired devices as well. 
                    var result = await service.GetCharacteristicsAsync(BluetoothCacheMode.Uncached);
                    if (result.Status == GattCommunicationStatus.Success)
                    {
                        characteristics = result.Characteristics;
                        Debug.WriteLine($"Characteristics Count ===> {characteristics.Count}");
                        foreach (GattCharacteristic characteristic in characteristics)
                        {
                            Debug.WriteLine($"Characteristic Name ===> {DisplayHelper.GetCharacteristicName(characteristic)}");
                            Debug.WriteLine($"Characteristic Uuid ===> {characteristic.Uuid}");
                            if (DisplayHelper.GetCharacteristicName(characteristic) == "14069")
                            {
                                selectedCharacteristic = characteristic;
                                break;
                            }
                        }
                        if (selectedCharacteristic != null)
                        {
                            //await GetToken();
                            ConnectButton.IsEnabled = true;

                        }
                    }
                    else
                    {
                        rootPage.NotifyUser("Error accessing service.", NotifyType.ErrorMessage);

                        // On error, act as if there are no characteristics.
                        characteristics = new List<GattCharacteristic>();
                    }
                }
                else
                {
                    // Not granted access
                    rootPage.NotifyUser("Error accessing service.", NotifyType.ErrorMessage);

                    // On error, act as if there are no characteristics.
                    characteristics = new List<GattCharacteristic>();

                }
            }
            catch (Exception ex)
            {
                rootPage.NotifyUser("Restricted service. Can't read characteristics: " + ex.Message,
                    NotifyType.ErrorMessage);
                // On error, act as if there are no characteristics.
                characteristics = new List<GattCharacteristic>();
            }
        }

        private async Task GetToken()
        {
            if (String.IsNullOrEmpty(DeviceKeyValue.Text))
            {
                return;
            }
            byte[] writeArray = PacketHelper.GetTokenPacket(DeviceKeyValue.Text);

            // 바이트 배열을 16진수 문자열로 변환하여 콘솔 로그에 출력
            Debug.WriteLine("GetToken 바이트 배열 내용 : " + BitConverter.ToString(writeArray).Replace("-", " "));

            var writeSuccessful = await WriteDataAndReadAsync(writeArray);

            /*
            var writeBuffer = CryptographicBuffer.CreateFromByteArray(writeArray);

            var writeSuccessful = await WriteBufferToSelectedCharacteristicAsync(writeBuffer);
            Debug.WriteLine($"WriteBufferToSelectedCharacteristicAsync 데이터 전송 : {writeSuccessful}");
            if (writeSuccessful)
            {
                AddValueChangedHandler();
                await ReadDataAsync();
                //await ReadDataAsync(LockerCallType.Token);
            }
            */
        }

        public async Task<bool> WriteDataAndReadAsync(byte[] data)
        {
            if (selectedCharacteristic != null)
            {
                var writer = new DataWriter();
                writer.WriteBytes(data);
                var result = await selectedCharacteristic.WriteValueAsync(writer.DetachBuffer());
                if (result == GattCommunicationStatus.Success)
                {
                    Debug.WriteLine("Data sent successfully");
                    var readResult = await selectedCharacteristic.ReadValueAsync();
                    if (readResult.Status == GattCommunicationStatus.Success)
                    {
                        var reader = Windows.Storage.Streams.DataReader.FromBuffer(readResult.Value);
                        var readBytes = new byte[readResult.Value.Length];
                        reader.ReadBytes(readBytes);
                        Debug.WriteLine("ReadDataAsync 수신된 dataBytes: " + BitConverter.ToString(readBytes));

                        byte[] resultBytes = PacketHelper.Decrypt(readBytes, PacketHelper.key);
                        rootPage.NotifyUser($"Read result: {BitConverter.ToString(resultBytes)}", NotifyType.StatusMessage);
                    }
                    else
                    {
                        Debug.WriteLine($"Failed to read data, status: {readResult.Status}");
                    }
                }
                else
                {
                    Debug.WriteLine($"Failed to send data, status: {result}");
                }
            }
            return false;
        }

        public async Task ReadDataAsync()
        {
            if (selectedCharacteristic != null)
            {
                GattReadResult result = await selectedCharacteristic.ReadValueAsync(BluetoothCacheMode.Uncached);
                Debug.WriteLine($"ReadDataAsync result : {result.Status}");

                if (result.Status == GattCommunicationStatus.Success)
                {
                    var reader = DataReader.FromBuffer(result.Value);
                    byte[] readBytes = new byte[reader.UnconsumedBufferLength];
                    reader.ReadBytes(readBytes);
                    Debug.WriteLine("ReadDataAsync 수신된 dataBytes: " + BitConverter.ToString(readBytes));

                    //byte[] resultBytes = PacketHelper.Decrypt(readBytes, PacketHelper.ConvertIntArrayToHexByteArray(PacketHelper.KEY_LOCKER_OKGSS101_1));
                    byte[] resultBytes = PacketHelper.Decrypt(readBytes, PacketHelper.key);
                    //byte[] resultBytes = PacketHelper.Decrypt(readBytes, PacketHelper.HexStringToByteArray(DeviceKeyValue.Text));
                    string formattedResult = BitConverter.ToString(resultBytes);
                    Debug.WriteLine("formattedResult : " + formattedResult);
                    rootPage.NotifyUser($"Read result: {formattedResult}", NotifyType.StatusMessage);
                }
                else
                {
                    rootPage.NotifyUser($"Read failed: {result.Status}", NotifyType.ErrorMessage);
                }
            }
            else
            {
                Debug.WriteLine("GATT 특성이 초기화되지 않았음");
            }
        }

        public async Task<bool> WriteDataAsync(byte[] data)
        {
            if (selectedCharacteristic != null)
            {
                // 바이트 배열을 16진수 문자열로 변환하여 콘솔 로그에 출력
                string hexString = BitConverter.ToString(data).Replace("-", " ");
                Debug.WriteLine("바이트 배열 내용 (16진수): " + hexString);

                var writer = new DataWriter();
                writer.WriteBytes(data);

                GattCommunicationStatus status = GattCommunicationStatus.Unreachable;
                try
                {
                    status = await selectedCharacteristic.WriteValueAsync(writer.DetachBuffer());
                    // 작업이 성공했을 때 수행해야 하는 작업
                }
                catch (Exception ex)
                {
                    // 예외 처리 코드를 추가하여 예외를 콘솔 또는 로그에 기록하십시오.
                    Debug.WriteLine($"Exception occurred: {ex.Message}");
                    Debug.WriteLine($"Exception occurred: {ex.StackTrace}");
                    // 그 외 오류 처리 작업을 수행하십시오.
                }
                //GattCommunicationStatus status = await selectedCharacteristic.WriteValueAsync(writer.DetachBuffer());

                if (status == GattCommunicationStatus.Success)
                {
                    Debug.WriteLine("데이터 전송 성공");
                    selectedCharacteristic.ValueChanged += Characteristic_ValueChanged;
                    return true;
                }
                else
                {
                    Debug.WriteLine("데이터 전송 실패");
                }
            }
            else
            {
                Debug.WriteLine("GATT 특성이 초기화되지 않았음");
            }
            return false;
        }

        public async Task<byte[]> ReadDataAsync(LockerCallType callType)
        {
            if (selectedCharacteristic != null)
            {
                GattReadResult result = await selectedCharacteristic.ReadValueAsync(BluetoothCacheMode.Uncached);

                Debug.WriteLine($"ReadDataAsync result : {result.Status}");
                if (result.Status == GattCommunicationStatus.Success)
                {
                    var reader = DataReader.FromBuffer(result.Value);
                    byte[] data = new byte[reader.UnconsumedBufferLength];
                    reader.ReadBytes(data);
                    return data;
                }
                else
                {
                    Debug.WriteLine("데이터 수신 실패");
                    return null;
                }
            }
            else
            {
                Debug.WriteLine("GATT 특성이 초기화되지 않았음");
                return null;
            }
        }

        private async Task<bool> WriteBufferToSelectedCharacteristicAsync(IBuffer buffer)
        {
            try
            {
                // BT_Code: Writes the value from the buffer to the characteristic.
                var result = await selectedCharacteristic.WriteValueWithResultAsync(buffer);
                Debug.WriteLine($"Status : {result.Status}, GetType : {result.GetType()}, ToString : {result.ToString()}");

                if (result.Status == GattCommunicationStatus.Success)
                {
                    rootPage.NotifyUser("Successfully wrote value to device", NotifyType.StatusMessage);
                    return true;
                }
                else
                {
                    rootPage.NotifyUser($"Write failed: {result.Status}", NotifyType.ErrorMessage);
                    return false;
                }
            }
            catch (Exception ex) when (ex.HResult == E_BLUETOOTH_ATT_INVALID_PDU)
            {
                Debug.WriteLine($"E_BLUETOOTH_ATT_INVALID_PDU : {ex.Message}");
                rootPage.NotifyUser(ex.Message, NotifyType.ErrorMessage);
                return false;
            }
            catch (Exception ex) when (ex.HResult == E_BLUETOOTH_ATT_WRITE_NOT_PERMITTED || ex.HResult == E_ACCESSDENIED)
            {
                Debug.WriteLine($"E_ACCESSDENIED : {ex.Message}");
                // This usually happens when a device reports that it support writing, but it actually doesn't.
                rootPage.NotifyUser(ex.Message, NotifyType.ErrorMessage);
                return false;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"WriteBufferToSelectedCharacteristicAsync : {ex.Message}");
                Debug.WriteLine($"WriteBufferToSelectedCharacteristicAsync : {ex.StackTrace}");
                // This usually happens when a device reports that it support writing, but it actually doesn't.
                rootPage.NotifyUser(ex.Message, NotifyType.ErrorMessage);
                return false;
            }
        }

        #endregion

        #region Enumerating Services
        private async Task<bool> ClearBluetoothLEDeviceAsync()
        {
            if (subscribedForNotifications)
            {
                if (registeredCharacteristic.CharacteristicProperties.HasFlag(GattCharacteristicProperties.Write))
                {
                    // Need to clear the CCCD from the remote device so we stop receiving notifications
                    var result = await registeredCharacteristic.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.None);
                    if (result != GattCommunicationStatus.Success)
                    {
                        return false;
                    }
                    else
                    {
                        selectedCharacteristic.ValueChanged -= Characteristic_ValueChanged;
                        subscribedForNotifications = false;
                    }
                }
                else
                {
                    Debug.WriteLine("Characteristic does not support write operations.");
                }
            }
            if (selectedCharacteristic != null) selectedCharacteristic.ValueChanged -= Characteristic_ValueChanged;
            bluetoothLeDevice?.Dispose();
            bluetoothLeDevice = null;
            return true;
        }
        #endregion

        private void AddValueChangedHandler()
        {
            if (!subscribedForNotifications)
            {
                registeredCharacteristic = selectedCharacteristic;
                registeredCharacteristic.ValueChanged += Characteristic_ValueChanged;
                subscribedForNotifications = true;
            }
        }

        private void RemoveValueChangedHandler()
        {
            if (subscribedForNotifications)
            {
                registeredCharacteristic.ValueChanged -= Characteristic_ValueChanged;
                registeredCharacteristic = null;
                subscribedForNotifications = false;
            }
        }

        private async void Characteristic_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            // BT_Code: An Indicate or Notify reported that the value has changed.
            // Display the new value with a timestamp.
            var newValue = FormatValueByPresentation(args.CharacteristicValue, presentationFormat);
            var message = $"Value at {DateTime.Now:hh:mm:ss.FFF}: {newValue}";
            Debug.WriteLine($"newValue : {message}");
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
                () => CharacteristicLatestValue.Text = message);
        }

        private string FormatValueByPresentation(IBuffer buffer, GattPresentationFormat format)
        {
            // BT_Code: For the purpose of this sample, this function converts only UInt32 and
            // UTF-8 buffers to readable text. It can be extended to support other formats if your app needs them.
            byte[] data;
            CryptographicBuffer.CopyToByteArray(buffer, out data);
            if (format != null)
            {
                if (format.FormatType == GattPresentationFormatTypes.UInt32 && data.Length >= 4)
                {
                    return BitConverter.ToInt32(data, 0).ToString();
                }
                else if (format.FormatType == GattPresentationFormatTypes.Utf8)
                {
                    try
                    {
                        return Encoding.UTF8.GetString(data);
                    }
                    catch (ArgumentException)
                    {
                        return "(error: Invalid UTF-8 string)";
                    }
                }
                else
                {
                    // Add support for other format types as needed.
                    return "Unsupported format: " + CryptographicBuffer.EncodeToHexString(buffer);
                }
            }
            else if (data != null)
            {
                // We don't know what format to use. Let's try some well-known profiles, or default back to UTF-8.
                if (selectedCharacteristic.Uuid.Equals(GattCharacteristicUuids.HeartRateMeasurement))
                {
                    try
                    {
                        return "Heart Rate: " + ParseHeartRateValue(data).ToString();
                    }
                    catch (ArgumentException)
                    {
                        return "Heart Rate: (unable to parse)";
                    }
                }
                else if (selectedCharacteristic.Uuid.Equals(GattCharacteristicUuids.BatteryLevel))
                {
                    try
                    {
                        // battery level is encoded as a percentage value in the first byte according to
                        // https://www.bluetooth.com/specifications/gatt/viewer?attributeXmlFile=org.bluetooth.characteristic.battery_level.xml
                        return "Battery Level: " + data[0].ToString() + "%";
                    }
                    catch (ArgumentException)
                    {
                        return "Battery Level: (unable to parse)";
                    }
                }
                else
                {
                    try
                    {
                        return "Unknown format: " + Encoding.UTF8.GetString(data);
                    }
                    catch (ArgumentException)
                    {
                        return "Unknown format";
                    }
                }
            }
            else
            {
                return "Empty data received";
            }
            return "Unknown format";
        }

        /// <summary>
        /// Process the raw data received from the device into application usable data,
        /// according the the Bluetooth Heart Rate Profile.
        /// https://www.bluetooth.com/specifications/gatt/viewer?attributeXmlFile=org.bluetooth.characteristic.heart_rate_measurement.xml&u=org.bluetooth.characteristic.heart_rate_measurement.xml
        /// This function throws an exception if the data cannot be parsed.
        /// </summary>
        /// <param name="data">Raw data received from the heart rate monitor.</param>
        /// <returns>The heart rate measurement value.</returns>
        private static ushort ParseHeartRateValue(byte[] data)
        {
            // Heart Rate profile defined flag values
            const byte heartRateValueFormat = 0x01;

            byte flags = data[0];
            bool isHeartRateValueSizeLong = ((flags & heartRateValueFormat) != 0);

            if (isHeartRateValueSizeLong)
            {
                return BitConverter.ToUInt16(data, 1);
            }
            else
            {
                return data[1];
            }
        }

    }
}
