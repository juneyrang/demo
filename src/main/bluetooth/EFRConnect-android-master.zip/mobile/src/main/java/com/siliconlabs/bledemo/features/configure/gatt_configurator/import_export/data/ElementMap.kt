package com.siliconlabs.bledemo.features.configure.gatt_configurator.import_export.data

class ElementMap<TagName, TagValue> : HashMap<TagName, TagValue>() {
}