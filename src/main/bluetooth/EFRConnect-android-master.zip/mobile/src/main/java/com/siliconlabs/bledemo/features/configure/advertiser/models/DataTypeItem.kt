package com.siliconlabs.bledemo.features.configure.advertiser.models

class DataTypeItem(
        val identifier: String,
        val name: String,
        var enabled: Boolean = true
)