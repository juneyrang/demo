package com.siliconlabs.bledemo.features.demo.blinky.models

enum class LightState {
    ON,
    OFF,
    TOGGLING_ON,
    TOGGLING_OFF
}