package com.siliconlabs.bledemo.features.configure.gatt_configurator.import_export.data

class AttributeMap<AttributeName, AttributeValue>() : HashMap<AttributeName, AttributeValue>()