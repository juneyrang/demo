package com.siliconlabs.bledemo.features.configure.advertiser.enums

enum class DataMode {
    ADVERTISING_DATA,
    SCAN_RESPONSE_DATA
}