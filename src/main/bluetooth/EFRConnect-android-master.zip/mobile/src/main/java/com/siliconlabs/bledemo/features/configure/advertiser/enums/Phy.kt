package com.siliconlabs.bledemo.features.configure.advertiser.enums

enum class Phy {
    PHY_1M,
    PHY_2M,
    PHY_LE_CODED
}