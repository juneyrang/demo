package com.siliconlabs.bledemo.features.configure.gatt_configurator.models

enum class SearchMode {
    BY_NAME,
    BY_UUID
}