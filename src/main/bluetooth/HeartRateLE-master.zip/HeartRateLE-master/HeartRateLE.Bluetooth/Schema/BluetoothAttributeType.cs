﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeartRateLE.Bluetooth.Schema
{
    public enum BluetoothAttributeType
    {
        Service = 0,
        Characteristic = 1,
        Descriptor = 2
    }
}
