param([String] $filePath)


$text = Get-Content $filePath
 
Write-Host $text