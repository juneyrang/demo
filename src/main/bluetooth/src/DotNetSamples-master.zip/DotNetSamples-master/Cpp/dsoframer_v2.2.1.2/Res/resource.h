//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dsoframer.rc
//
#define IDR_TYPELIB                     1
#define RES_DSO_E_UNKNOWN               1
#define RES_DSO_E_INVALIDPROGID         2
#define RES_DSO_E_INVALIDSERVER         3
#define RES_DSO_E_COMMANDNOTSUPPORTED   4
#define RES_DSO_E_DOCUMENTREADONLY      5
#define RES_DSO_E_REQUIRESMSDAIPP       6
#define RES_DSO_E_DOCUMENTNOTOPEN       7
#define RES_DSO_E_INMODALSTATE          8
#define RES_DSO_E_NOTBEENSAVED          9
#define IDB_TOOLBOX                     102
#define IDB_TOOLBAR                     103
#define IDR_BINDMENU                    104
#define IDI_SMALLOFFDOC                 105
#define MNU_NEW                         40001
#define MNU_OPEN                        40002
#define MNU_CLOSE                       40003
#define MNU_SAVE                        40004
#define MNU_SAVEAS                      40005
#define MNU_PGSETUP                     40006
#define MNU_PRINT                       40007
#define MNU_PROPS                       40008
#define MNU_PRINTPV                     40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
