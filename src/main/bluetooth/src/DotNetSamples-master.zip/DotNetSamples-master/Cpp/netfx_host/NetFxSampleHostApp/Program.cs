﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Sample .NET App - running...");
    }
}
