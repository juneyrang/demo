﻿using BLE.Client.ViewModels;
using MvvmCross.Forms.Views;

namespace BLE.Client.Pages
{
    public partial class DescriptorListPage : MvxContentPage<DescriptorListViewModel>
    {
        public DescriptorListPage()
        {
            InitializeComponent();
        }
    }
}
