﻿using BLE.Client.ViewModels;
using MvvmCross.Forms.Views;
using Xamarin.Forms;

namespace BLE.Client.Pages
{
    public partial class CharacteristicListPage : MvxContentPage<CharacteristicListViewModel>
    {
        public CharacteristicListPage()
        {
            InitializeComponent();
        }
    }
}
