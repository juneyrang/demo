﻿namespace Cross.BluetoothLe
{
  public enum ConnectionInterval
  {
    Normal = 0,
    High = 1,
    Low = 2
  }
}
