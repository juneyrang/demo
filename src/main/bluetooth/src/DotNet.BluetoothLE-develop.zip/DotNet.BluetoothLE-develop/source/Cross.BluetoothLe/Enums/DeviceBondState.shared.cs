﻿namespace Cross.BluetoothLe
{
  public enum DeviceBondState
  {
    NotBonded,
    Bonding,
    Bonded
  }
}
