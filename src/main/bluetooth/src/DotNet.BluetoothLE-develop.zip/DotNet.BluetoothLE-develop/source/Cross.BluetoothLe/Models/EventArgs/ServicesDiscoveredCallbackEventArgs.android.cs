﻿namespace Cross.BluetoothLe.EventArgs
{
  public class ServicesDiscoveredCallbackEventArgs : System.EventArgs
  {
  }
}
