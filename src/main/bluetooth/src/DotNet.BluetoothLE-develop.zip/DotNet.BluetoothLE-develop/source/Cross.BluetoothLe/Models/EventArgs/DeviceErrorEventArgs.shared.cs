﻿namespace Cross.BluetoothLe.EventArgs
{
  public class DeviceErrorEventArgs : DeviceEventArgs
  {
    public string ErrorMessage;
  }
}
