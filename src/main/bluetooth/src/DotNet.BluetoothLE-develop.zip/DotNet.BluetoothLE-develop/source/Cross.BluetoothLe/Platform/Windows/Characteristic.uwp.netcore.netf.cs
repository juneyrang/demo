﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Cross.BluetoothLe.EventArgs;
using Cross.BluetoothLe.Extensions;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Security.Cryptography;

namespace Cross.BluetoothLe
{
  public partial class Characteristic
  {
    /// <summary>
    /// Value of the characteristic to be stored locally after
    /// update notification or read
    /// </summary>
    private byte[] _value;

    protected Guid NativeGuid => NativeCharacteristic.Uuid;

    protected string NativeUuid => NativeCharacteristic.Uuid.ToString();

    protected byte[] NativeValue => _value ?? new byte[0]; // return empty array if value is equal to null

    protected string NativeName => string.IsNullOrEmpty(NativeCharacteristic.UserDescription) ? KnownCharacteristics.Lookup(Id).Name : NativeCharacteristic.UserDescription;

    protected CharacteristicPropertyType NativeProperties => (CharacteristicPropertyType)(int)NativeCharacteristic.CharacteristicProperties;

    protected GattCharacteristic NativeCharacteristic { get; private set; }

    public Characteristic(GattCharacteristic nativeCharacteristic, Service service) : this(service)
    {
      NativeCharacteristic = nativeCharacteristic;
    }

    protected async Task<IReadOnlyList<Descriptor>> GetDescriptorsNativeAsync()
    {
      var descriptorsResult = await NativeCharacteristic.GetDescriptorsAsync(BluetoothLE.CacheModeGetDescriptors);
      descriptorsResult.ThrowIfError();

      return descriptorsResult.Descriptors?
        .Select(nativeDescriptor => new Descriptor(nativeDescriptor, this))
        .Cast<Descriptor>()
        .ToList();
    }

    protected async Task<byte[]> ReadNativeAsync()
    {
      var readResult = await NativeCharacteristic.ReadValueAsync(BluetoothLE.CacheModeCharacteristicRead);
      return _value = readResult.GetValueOrThrowIfError();
    }

    protected async Task StartUpdatesNativeAsync()
    {
      NativeCharacteristic.ValueChanged -= OnCharacteristicValueChanged;
      NativeCharacteristic.ValueChanged += OnCharacteristicValueChanged;

      var result = await NativeCharacteristic.WriteClientCharacteristicConfigurationDescriptorWithResultAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);
      result.ThrowIfError();
    }

    protected async Task StopUpdatesNativeAsync()
    {
      NativeCharacteristic.ValueChanged -= OnCharacteristicValueChanged;

      var result = await NativeCharacteristic.WriteClientCharacteristicConfigurationDescriptorWithResultAsync(GattClientCharacteristicConfigurationDescriptorValue.None);
      result.ThrowIfError();
    }

    protected async Task<bool> WriteNativeAsync(byte[] data, CharacteristicWriteType writeType)
    {
      var result = await NativeCharacteristic.WriteValueWithResultAsync(
        CryptographicBuffer.CreateFromByteArray(data),
        writeType == CharacteristicWriteType.WithResponse ? GattWriteOption.WriteWithResponse : GattWriteOption.WriteWithoutResponse);

      result.ThrowIfError();
      return true;
    }

    /// <summary>
    /// Handler for when the characteristic value is changed. Updates the
    /// stored value
    /// </summary>
    private void OnCharacteristicValueChanged(object sender, GattValueChangedEventArgs e)
    {
      _value = e.CharacteristicValue?.ToArray(); //add value to array
      ValueUpdated?.Invoke(this, new CharacteristicUpdatedEventArgs(this));
    }
  }
}
