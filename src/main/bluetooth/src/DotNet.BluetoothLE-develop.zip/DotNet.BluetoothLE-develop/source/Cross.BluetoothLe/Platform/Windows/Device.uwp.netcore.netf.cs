﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cross.BluetoothLe.Extensions;
using Windows.Devices.Bluetooth;

namespace Cross.BluetoothLe
{
  public partial class Device
  {
    internal ObservableBluetoothLEDevice NativeDevice { get; private set; }

    internal Device(Adapter adapter, BluetoothLEDevice nativeDevice, int rssi, Guid id, IReadOnlyList<AdvertisementRecord> advertisementRecords = null) : this(adapter)
    {
      NativeDevice = new ObservableBluetoothLEDevice(nativeDevice.DeviceInformation);

      Rssi = rssi;
      Id = id;
      Name = nativeDevice.Name;
      AdvertisementRecords = advertisementRecords;

      NativeDevice.OnNameChanged += (s, name) => { Name = name; };
    }

    public virtual void Dispose()
    {
      Adapter?.DisconnectDeviceAsync(this);
    }

    internal void Update(short btAdvRawSignalStrengthInDBm, IReadOnlyList<AdvertisementRecord> advertisementData)
    {
      this.Rssi = btAdvRawSignalStrengthInDBm;

      MergeOrUpdateAdvertising(advertisementData);

      //this.AdvertisementRecords = advertisementData;
    }

    internal Task<bool> UpdateRssiNativeAsync()
    {
      //No current method to update the Rssi of a device
      //In future implementations, maybe listen for device's advertisements

      Trace.Message("Request RSSI not supported in UWP");

      return Task.FromResult(true);
    }

    private async Task<IReadOnlyList<Service>> GetServicesNativeAsync()
    {
      var result = await NativeDevice.BluetoothLEDevice.GetGattServicesAsync(BluetoothLE.CacheModeGetServices);
      result.ThrowIfError();

      return result.Services?
          .Select(nativeService => new Service(nativeService, this))
          .Cast<Service>()
          .ToList();
    }

    private async Task<Service> GetServiceNativeAsync(Guid id)
    {
      var result = await NativeDevice.BluetoothLEDevice.GetGattServicesForUuidAsync(id, BluetoothLE.CacheModeGetServices);
      result.ThrowIfError();

      var nativeService = result.Services?.FirstOrDefault();
      return nativeService != null ? new Service(nativeService, this) : null;
    }

    private DeviceState GetState()
    {
      if (NativeDevice.IsConnected)
      {
        return DeviceState.Connected;
      }

      return NativeDevice.IsPaired ? DeviceState.Limited : DeviceState.Disconnected;
    }

    private Task<int> RequestMtuNativeAsync(int requestValue)
    {
      Trace.Message("Request MTU not supported in UWP");
      return Task.FromResult(-1);
    }

    private bool UpdateConnectionIntervalNative(ConnectionInterval interval)
    {
      Trace.Message("Update Connection Interval not supported in UWP");
      return false;
    }

    internal void MergeOrUpdateAdvertising(IReadOnlyList<AdvertisementRecord> advertisementRecords)
    {
      var adverts = this.AdvertisementRecords.ToList();

      foreach (var adv in advertisementRecords)
      {
        var matcing = adverts.FirstOrDefault(x => x.Type.Equals(adv.Type));

        if (matcing != null)
          adverts.Remove(matcing);

        adverts.Add(adv);
      }

      this.AdvertisementRecords = adverts;
    }
  }
}
