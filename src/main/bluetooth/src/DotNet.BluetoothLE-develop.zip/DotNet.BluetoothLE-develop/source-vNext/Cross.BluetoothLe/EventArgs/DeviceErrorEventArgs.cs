﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cross.BluetoothLe.EventArgs
{
  public class DeviceErrorEventArgs : DeviceEventArgs
  {
    public string ErrorMessage;
  }
}
