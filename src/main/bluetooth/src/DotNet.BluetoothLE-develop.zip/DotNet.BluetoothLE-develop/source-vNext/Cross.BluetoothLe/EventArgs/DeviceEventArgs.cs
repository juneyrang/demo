﻿namespace Cross.BluetoothLe.EventArgs
{
  public class DeviceEventArgs : System.EventArgs
  {
    public Device Device;
  }
}
